"""
generate_dataset.py
--------------------
Generates a realistic synthetic dataset for the
"Seasonal Agriculture Performance Analysis" project.

The dataset simulates agricultural records collected across seasons,
regions and crop types, capturing environmental conditions, farming
practices, resource usage, production and economic performance.

Run:
    python generate_dataset.py
Produces:
    agriculture_seasonal_data.csv  (in the same folder)
"""

import numpy as np
import pandas as pd

np.random.seed(42)

N = 3000

seasons = ["Kharif", "Rabi", "Zaid"]
season_weights = [0.42, 0.42, 0.16]

regions = ["North", "South", "East", "West", "Central"]

crops_by_season = {
    "Kharif": ["Rice", "Maize", "Cotton", "Soybean", "Sugarcane", "Groundnut"],
    "Rabi": ["Wheat", "Mustard", "Barley", "Chickpea", "Peas"],
    "Zaid": ["Watermelon", "Cucumber", "Moong Dal", "Fodder Crops"],
}

soil_types = ["Alluvial", "Black", "Red", "Laterite", "Sandy"]
irrigation_types = ["Canal", "Borewell", "Drip", "Sprinkler", "Rainfed"]

# Base seasonal climate profiles (mean, std)
season_climate = {
    "Kharif": {"rainfall": (850, 180), "temp": (29, 3), "humidity": (78, 8)},
    "Rabi":   {"rainfall": (150, 60),  "temp": (18, 4), "humidity": (55, 10)},
    "Zaid":   {"rainfall": (60, 30),   "temp": (34, 3), "humidity": (40, 9)},
}

region_soil_bias = {
    "North": ["Alluvial", "Sandy"],
    "South": ["Red", "Laterite"],
    "East": ["Alluvial", "Red"],
    "West": ["Black", "Sandy"],
    "Central": ["Black", "Red"],
}

rows = []
start_year = 2019
end_year = 2025

for i in range(N):
    year = np.random.randint(start_year, end_year + 1)
    season = np.random.choice(seasons, p=season_weights)
    region = np.random.choice(regions)
    crop = np.random.choice(crops_by_season[season])
    soil = np.random.choice(region_soil_bias[region] + soil_types) \
        if np.random.rand() < 0.7 else np.random.choice(soil_types)
    irrigation = np.random.choice(
        irrigation_types,
        p=[0.28, 0.24, 0.18, 0.12, 0.18] if season != "Zaid" else [0.15, 0.25, 0.30, 0.15, 0.15]
    )

    clim = season_climate[season]
    rainfall = max(5, np.random.normal(*clim["rainfall"]))
    temperature = np.clip(np.random.normal(*clim["temp"]), 5, 48)
    humidity = np.clip(np.random.normal(*clim["humidity"]), 10, 100)

    area = np.round(np.random.gamma(shape=2.2, scale=1.8) + 0.3, 2)  # hectares
    fertilizer_rate = np.random.normal(120, 35)  # kg per hectare
    fertilizer_used = max(5, fertilizer_rate) * area
    pesticide_used = max(0.2, np.random.normal(6, 2.5)) * area
    water_usage = {
        "Canal": 6200, "Borewell": 5400, "Drip": 3100, "Sprinkler": 3800, "Rainfed": 900
    }[irrigation] * area * np.random.normal(1, 0.15)
    water_usage = max(200, water_usage)
    labor_hours = np.random.normal(180, 45) * area
    labor_hours = max(20, labor_hours)

    # Crop-specific base yield (kg/hectare) and price (per kg)
    crop_profile = {
        "Rice": (3800, 22), "Maize": (3200, 18), "Cotton": (450, 62),
        "Soybean": (1400, 40), "Sugarcane": (68000, 3.2), "Groundnut": (1500, 55),
        "Wheat": (3300, 21), "Mustard": (1300, 48), "Barley": (2600, 19),
        "Chickpea": (1200, 55), "Peas": (1600, 35),
        "Watermelon": (22000, 9), "Cucumber": (18000, 11),
        "Moong Dal": (700, 70), "Fodder Crops": (25000, 2.5),
    }
    base_yield, base_price = crop_profile[crop]

    # Environmental & practice effects on yield
    rain_opt = clim["rainfall"][0]
    rain_penalty = -0.00035 * (rainfall - rain_opt) ** 2 / max(1, rain_opt)
    temp_penalty = -0.008 * (temperature - clim["temp"][0]) ** 2
    fert_effect = 0.15 * np.log1p(max(5, fertilizer_rate))
    irrigation_boost = {
        "Drip": 0.18, "Sprinkler": 0.10, "Canal": 0.06, "Borewell": 0.04, "Rainfed": -0.10
    }[irrigation]

    yield_multiplier = 1 + rain_penalty + temp_penalty * 0.01 + fert_effect * 0.01 + irrigation_boost
    yield_multiplier = np.clip(yield_multiplier + np.random.normal(0, 0.10), 0.35, 1.6)

    yield_per_ha = max(50, base_yield * yield_multiplier)
    production = yield_per_ha * area  # kg

    price_fluct = base_price * np.random.normal(1, 0.12)
    price = max(0.5, price_fluct)

    revenue = production * price
    cost_cultivation = (
        fertilizer_used * 28 +           # cost per kg fertilizer
        pesticide_used * 320 +           # cost per kg pesticide
        labor_hours * 45 +               # cost per labor hour
        water_usage * 0.06 +             # cost per liter water
        area * 4200                      # fixed cost per hectare (seeds, land prep etc.)
    )
    profit = revenue - cost_cultivation

    rows.append({
        "Record_ID": f"AG{i+1:05d}",
        "Year": year,
        "Season": season,
        "Region": region,
        "Crop_Type": crop,
        "Soil_Type": soil,
        "Irrigation_Type": irrigation,
        "Area_Hectares": area,
        "Rainfall_mm": round(rainfall, 1),
        "Temperature_C": round(temperature, 1),
        "Humidity_percent": round(humidity, 1),
        "Fertilizer_Used_kg": round(fertilizer_used, 1),
        "Pesticide_Used_kg": round(pesticide_used, 2),
        "Water_Usage_Liters": round(water_usage, 0),
        "Labor_Hours": round(labor_hours, 1),
        "Yield_kg_per_hectare": round(yield_per_ha, 1),
        "Production_kg": round(production, 1),
        "Market_Price_per_kg": round(price, 2),
        "Revenue_INR": round(revenue, 2),
        "Cost_of_Cultivation_INR": round(cost_cultivation, 2),
        "Profit_INR": round(profit, 2),
    })

df = pd.DataFrame(rows)

# Introduce a small amount of realistic messiness for the cleaning stage
missing_idx = np.random.choice(df.index, size=int(0.03 * len(df)), replace=False)
df.loc[missing_idx, "Humidity_percent"] = np.nan

missing_idx2 = np.random.choice(df.index, size=int(0.015 * len(df)), replace=False)
df.loc[missing_idx2, "Pesticide_Used_kg"] = np.nan

dup_idx = np.random.choice(df.index, size=8, replace=False)
df = pd.concat([df, df.loc[dup_idx]], ignore_index=True)

# A few inconsistent text-casing entries to simulate real-world messiness
noisy_idx = np.random.choice(df.index, size=15, replace=False)
df.loc[noisy_idx, "Region"] = df.loc[noisy_idx, "Region"].str.upper()

df = df.sample(frac=1, random_state=7).reset_index(drop=True)

out_path = "agriculture_seasonal_data.csv"
df.to_csv(out_path, index=False)
print(f"Saved {len(df)} rows to {out_path}")
print(df.head())
